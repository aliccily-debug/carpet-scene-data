import os
from PIL import Image

BASE = r"C:\Users\zhoul\WorkBuddy\2026-08-25-20-25-47\white-bg"
OUT = os.path.join(BASE, "final")
os.makedirs(OUT, exist_ok=True)

jobs = [
    ("01-pouf/Product_photo_on_pure_white_ba_2026-09-13T12-10-46.png", "01-坐墩-pouf.png", True),
    ("02-floorlamp/Product_photo_on_pure_white_ba_2026-09-13T12-10-11.png", "02-落地灯-floor-lamp.png", False),
    ("03-lantern/Product_photo_on_pure_white_ba_2026-09-13T12-11-03.png", "03-灯笼台灯-lantern-lamp.png", False),
    ("Product_photo_on_pure_white_ba_2026-09-13T12-09-52.png", "04-圆形茶几-coffee-table.png", False),
]

for src, dst, crop_wm in jobs:
    p = os.path.join(BASE, *src.split("/"))
    im = Image.open(p).convert("RGB")
    w, h = im.size
    if crop_wm:
        # 裁掉右下角水印：底部 8%（约 82px）连同上边缘对齐，使其保持正方形
        cut = int(h * 0.082)
        side = min(w, h - cut)
        left = (w - side) // 2
        im = im.crop((left, 0, left + side, side))  # 保持正方形
    if im.size != (1024, 1024):
        im = im.resize((1024, 1024), Image.LANCZOS)
    out = os.path.join(OUT, dst)
    im.save(out, "PNG")
    print("saved", out, im.size)
