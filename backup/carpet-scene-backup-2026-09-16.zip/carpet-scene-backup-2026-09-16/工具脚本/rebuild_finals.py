# -*- coding: utf-8 -*-
"""重建 4 张白底成品图（参数与 2026-09-13 制作时完全一致）"""
import os
from PIL import Image

BASE = r"C:\Users\zhoul\WorkBuddy\2026-08-25-20-25-47\white-bg"
OUT = os.path.join(BASE, "final")
os.makedirs(OUT, exist_ok=True)

# 01 坐墩：最终版（subject bbox 39,293,990,820 -> 737px 居中 1024 纯白底、无影子）
im = Image.open(os.path.join(BASE, "01-pouf", "Clean_e_commerce_product_shot__2026-09-13T13-07-56.png")).convert("RGB")
x0, y0, x1, y1 = 39, 293, 990, 820
side = max(x1 - x0, y1 - y0)
cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
W, H = im.size
bx = min(max(cx - side // 2, 0), W - side)
by = min(max(cy - side // 2, 0), H - side)
crop = im.crop((bx, by, bx + side, by + side)).resize((737, 737), Image.LANCZOS)
canvas = Image.new("RGB", (1024, 1024), (255, 255, 255))
canvas.paste(crop, ((1024 - 737) // 2, (1024 - 737) // 2))
canvas.save(os.path.join(OUT, "01-坐墩-pouf.png"), "PNG")
print("01 ok")

# 02/03/04：直接方形化到 1024
jobs = [
    ("02-floorlamp/Product_photo_on_pure_white_ba_2026-09-13T12-10-11.png", "02-落地灯-floor-lamp.png"),
    ("03-lantern/Product_photo_on_pure_white_ba_2026-09-13T12-11-03.png", "03-灯笼台灯-lantern-lamp.png"),
    ("Product_photo_on_pure_white_ba_2026-09-13T12-09-52.png", "04-圆形茶几-coffee-table.png"),
]
for src, dst in jobs:
    im = Image.open(os.path.join(BASE, *src.split("/"))).convert("RGB")
    if im.size != (1024, 1024):
        im = im.resize((1024, 1024), Image.LANCZOS)
    im.save(os.path.join(OUT, dst), "PNG")
    print(dst, "ok")

for f in sorted(os.listdir(OUT)):
    print(round(os.path.getsize(os.path.join(OUT, f)) / 1024), "KB", f)
